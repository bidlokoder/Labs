#include "library.h"

library::library() 
{
}
void library::add_catalog() 
{
	string name;
	cin >> name;
	catalog newcat(name);
	cat.push_back(newcat);
}
void library::list_catalog() 
{
	for(int i=0; i<cat.size(); i++) 
	{
		cout << cat[i].Name() << endl;
	}
}
void library::add_sector() 
{
	string name;
	cin >> name;
	sector newsec(name);
	sect.push_back(newsec);
}
void library::list_sector() 
{
	for(int i=0; i<sect.size(); i++) 
	{
		cout << sect[i].Name() << endl;
	}
}
void library::add_book() 
{
	string sector_name;
	cin >> sector_name;
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector_name)
		{
			sect[i].add_book();
		}
	}
}
void library::list_book() 
{
	string sector_name;
	cin >> sector_name;
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector_name)
		{
			sect[i].list_book();
		}
	}
}
void library::add_category_book() 
{
	string category_name, sector_name, book_name;
	cin >> category_name >> sector_name >> book_name ;
	for(int i=0; i<cat.size(); i++) 
	{
		if(cat[i].Name()==category_name)
		{
			for(int j=0; j<sect.size(); j++) 
			{
				if(sect[j].Name()==sector_name) 
				{
					int k=sect[j].find_book(book_name);
					if(k!=-1)
					{
						cat[i].add_category_book(sect[j].get_book(k));
					}
				}
			}
		}
	}
}

void library::list_category_book() 
{
	string category_name;
	cin >> category_name;
	for(int i=0; i<cat.size(); i++) 
	{
		if(cat[i].Name()==category_name)
		{
			cat[i].list_category_book();
		}
	}
}
void library::digit_book() 
{
	string sector_name, book_name;
	cin >> sector_name >> book_name ;
	
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector_name) 
		{
			int k=sect[i].find_book(book_name);
			if(k!=-1)
			{
				sect[i].digit_book(k);
			}
			else 
			{
				cout << "Book not found" << endl;
			}
		}
	}
}
void library::download_book() 
{
	string sector_name, book_name;
	cin >> sector_name >> book_name ;
	
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector_name) 
		{
			int k=sect[i].find_book(book_name);
			if(k!=-1)
			{
				sect[i].download_book(k);
			}
			else 
			{
				cout << "Book not found" << endl;
			}
		}
	}
}
void library::find_book() 
{
	string book_name;
	cin >> book_name ;
	cout << "Book sectors:" << endl;
	for(int i=0; i<sect.size(); i++) 
	{
		int k=sect[i].find_book(book_name);
		if(k!=-1)
		{
			cout << sect[i].Name() << endl;
		}
	}
}
void library::move_book() 
{
	string sector1, sector2, book_name;
	cin >> sector1 >> sector2 >> book_name ;
	int l=-1;
	int m=-1;
	int k=-1;
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector1) 
		{
			l = i;
			k=sect[i].find_book(book_name);
			if(k==-1) 
			{
				cout << "Book not found" << endl;
			}
		}
		if(sect[i].Name()==sector2) 
		{
			m = i;
		}
	}
	if(k==-1) {
		return;
	}
	if((l==-1)||(m==-1)) 
	{
		cout << "Sector not found" << endl;
	}
	sect[m].add_book(*sect[l].get_book(k));
	sect[l].delete_book(k);
}
void library::delete_book() 
{
	string sector_name, book_name;
	cin >> sector_name >> book_name ;
	
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector_name) 
		{
			int k=sect[i].find_book(book_name);
			if(k!=-1)
			{
				sect[i].delete_book(k);
			}
			else 
			{
				cout << "Book not found" << endl;
			}
		}
	}
}
void library::merge_sector() 
{
	string sector1, sector2;
	cin >> sector1 >> sector2;
	int l=-1;
	int m=-1;
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector1) 
		{
			l = i;
		}
		if(sect[i].Name()==sector2) 
		{
			m = i;
		}
	}
	if((l==-1)||(m==-1)) 
	{
		cout << "Sector not found" << endl;
	}
	for(int i=0; i<sect[l].size(); i=0) 
	{
		sect[m].add_book(*sect[l].get_book(0));
		sect[l].delete_book(0);
	}
	sect.erase(sect.begin() + l);
}
void library::delete_sector() 
{
	string sector_name;
	cin >> sector_name;
	
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector_name) 
		{
			sect.erase(sect.begin() + i);
			return;
		}
	}
}
void library::divide_sector() 
{
	string sector_name, newsector;
	int n, ind=-1;
	vector<string> books;		
	cin >> sector_name >> newsector >> n;
	for(int i=0; i<n; i++)
	{
		string newbook;
		cin >> newbook;
		books.push_back(newbook);
	}
	sector newsec(newsector);
	sect.push_back(newsec);
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector_name) 
		{
			for(int j=0; j<n; j++) {
				int k=sect[i].find_book(books[j]);
				if(k!=-1)
				{
					sect[sect.size()-1].add_book(*(sect[i].get_book(k)));
					sect[i].delete_book(k);
				}
				else 
				{
					sect.erase(sect.begin() + (sect.size()-1));
					cout << "Book not found: " << books[j] << endl;
					return;
				}
			}
		}
	}
}
void library::history_book() 
{
	string sector_name, book_name;
	cin >> sector_name >> book_name ;
	
	for(int i=0; i<sect.size(); i++) 
	{
		if(sect[i].Name()==sector_name) 
		{
			int k=sect[i].find_book(book_name);
			if(k!=-1)
			{
				sect[i].history_book(k);
			}
			else 
			{
				cout << "Book not found" << endl;
			}
		}
	}
}
void library::save() 
{
	string file_name;
	cin >> file_name;
	ofstream file(file_name.c_str());
	file << sect.size() << endl;
	for(int i=0; i<sect.size(); i++) {
		sect[i].save(file);
	}
	file << cat.size() << endl;
	for(int i=0; i<cat.size(); i++) {
		cat[i].save(file);
	}
	file.close();
}
void library::open() 
{
	string file_name;
	cin >> file_name;
	ifstream file(file_name.c_str());
	int n;
	file >> n;
	for(int i=0; i<n; i++) 
	{
		string name;
		int m;
		file >> name >> m;
		sector newsec(name);
		for(int j=0; j<m; j++) 
		{
			bool dig, dow;
			file >> name >> dig >> dow;
			book newbook(name, dig, dow);
			newsec.add_book(newbook);
		}
		sect.push_back(newsec);
	}
	file >> n;
	for(int i=0; i<n; i++) 
	{
		string name;
		int m;
		file >> name >> m;
		catalog newcat(name);
		for(int j=0; j<m; j++) 
		{
			file >> name;
			for(int a=0; a<sect.size(); a++) 
			{
				int k=sect[a].find_book(name);
				if(k!=-1)
				{
					sect[i].digit_book(k);
					newcat.add_category_book(sect[i].get_book(k));
					break;
				}
			}
		}
		cat.push_back(newcat);
	}
}