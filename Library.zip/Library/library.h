#ifndef LIBRARY
#define LIBRARY
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include "catalog.h"
#include "sector.h"


class library {
	vector <catalog> cat;
	vector <sector> sect;
	public:
	library();
	void add_catalog();
	void list_catalog();
	void add_sector();
	void list_sector();
	void add_book();
	void list_book();
	void add_category_book();
	void list_category_book();
	void digit_book();
	void download_book();
	void find_book();
	void move_book();
	void delete_book();
	void merge_sector();
	void delete_sector();
	void divide_sector();
	void history_book();
	void save();
	void open();
};




#endif