#include "catalog.h"


catalog::catalog() 
{
	name = "";
}
catalog::catalog(string catalog_name) 
{
	name = catalog_name;
}
string catalog::Name() 
{
	return name;
}
void catalog::add_category_book(book* bookp) 
{
	books.push_back(bookp);
}
void catalog::list_category_book() 
{
	for(int i=0; i<books.size(); i++) 
	{
		cout << books[i]->Name() << endl;
	}
}
int catalog::size() 
{
	return books.size();
}
void catalog::save(ofstream& file) 
{
	file << name << endl;
	file << books.size() << endl;
	for(int i=0; i<books.size(); i++) 
	{
		file << books[i]->Name() << endl;
	}
}