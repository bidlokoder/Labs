#ifndef CATALOG
#define CATALOG 
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include "book.h"
using namespace std;




class catalog {
	string name;
	vector<book*> books;
	public:
	catalog();
	catalog(string catalog_name);
	string Name();
	void add_category_book(book* bookp);
	void list_category_book();
	int size();
	void save(ofstream& file);
};




#endif



