#include "book.h"

book::book()
{
	name = "";
	digital = false;
	downloaded = false;
	history.push_back("Was created");
}
book::book(string book_name) 
{
	name = book_name;
	digital = false;
	downloaded = false;
	history.push_back("Was created");
}

book::book(string book_name, bool book_digital, bool book_downloaded) 
{
	name = book_name;
	digital = book_digital;
	downloaded = book_downloaded;
	history.push_back("Was restored");
}
string book::Name() 
{
	return name;
}
void book::digit() 
{
	if(digital) 
	{
		cout << "Already digital" << endl;
	}
	else 
	{
		history.push_back("Was digited");
		digital = true;
	}
}
void book::download() 
{
	if(digital) 
	{
		history.push_back("Was downloaded");
		downloaded = true;
	}
	else
	{
		cout << "Book isn't digital" << endl;
	}
}

void book::add_history(string str) 
{
	history.push_back(str);
}
void book::History() 
{
	for(int i=0; i<history.size(); i++)
	{
		cout << history[i] << endl;
	}
}
void book::save(ofstream& file) 
{
	file << name << endl;
	file << digital << endl;
	file << downloaded << endl;
}