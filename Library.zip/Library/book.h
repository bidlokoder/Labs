#ifndef SECTOR
#define SECTOR 
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
using namespace std;

class book {
	string name;
	bool digital;
	bool downloaded;
	vector <string> history;
	public:
	book();
	book(string book_name);
	book(string book_name, bool book_digital, bool book_downloaded);
	string Name();
	void digit();
	void download();
	void add_history(string str);
	void History();
	void save(ofstream& file);
	
};
#endif