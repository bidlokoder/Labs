/*

Каталог библиотеки разбит на разделы по категориям: наука, техника, искусство, художка и т.п.

Фонд библиотеки разделен на несколько помещений. Книга может иметь несколько категорий. В библиотеке может быть несколько экземпляров одной книги.

Ведется процесс оцифрофки книг, оцифрованные книги можно скачать.

Процессы:

оцифровка книги +
поиск книги +
скачивание книги (если оцифрована) +
просмотр раздела каталога +
перемещение книги между помещениями +
добавление, объединение, разделение помещений +++
ведение история операций над книгой +
Необходимо реализовать функции сохранения и восстановления данных (история не сохраняется)

Библиотека
	Помещение
		Книга
	Категория
		Книга*
		
			
*/

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include "library.h"
using namespace std;


int main() {
	library lib;
	while(1) {
		string str;
		cout << "> ";
		cin >> str;
		if(str=="add_catalog") {
			lib.add_catalog();
		}
		if(str=="list_catalog") {
			lib.list_catalog();
		}
		if(str=="add_sector") {
			lib.add_sector();
		}
		if(str=="list_sector") {
			lib.list_sector();
		}
		if(str=="add_book") {
			lib.add_book();
		}
		if(str=="list_book") {
			lib.list_book();
		}
		if(str=="add_category_book") {
			lib.add_category_book();
		}
		if(str=="list_category_book") {
			lib.list_category_book();
		}
		if(str=="digit_book") {
			lib.digit_book();
		}
		if(str=="download_book") {
			lib.download_book();
		}
		if(str=="find_book") {
			lib.find_book();
		}
		if(str=="move_book") {
			lib.move_book();
		}
		if(str=="delete_book") {
			lib.delete_book();
		}
		if(str=="merge_sector") {
			lib.merge_sector();
		}
		if(str=="delete_sector") {
			lib.delete_sector();
		}
		if(str=="divide_sector") {
			lib.divide_sector();
		}
		if(str=="history_book") {
			lib.history_book();
		}
		if(str=="save") {
			lib.save();
		}
		if(str=="open") {
			lib.open();
		}
		if(str=="exit") {
			return 0;
		}
	}
	return 0;
}