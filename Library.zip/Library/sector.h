#ifndef _SECTOR
#define _SECTOR 
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include "book.h"
using namespace std;

class sector {
	string name;
	vector<book> books;
	public:
	sector();
	sector(string sector_name);
	string Name();
	void add_book();
	void add_book(book newbook);
	void list_book();
	int find_book(string name);
	book* get_book(int i);
	void digit_book(int i);
	void download_book(int i);
	void delete_book(int i);
	int size();
	void history_book(int i);
	void save(ofstream& file);
};

#endif

	