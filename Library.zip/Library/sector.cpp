#include "sector.h"

sector::sector() 
{
	name = "";
}
sector::sector(string sector_name) 
{
	name = sector_name;
}
string sector::Name() 
{
	return name;
}
void sector::add_book() 
{
	string book_name;
	cin >> book_name;
	book newbook(book_name);
	books.push_back(newbook);
	books[books.size()-1].add_history("Was placed in "+name);
}
void sector::add_book(book newbook) 
{
	books.push_back(newbook);
	books[books.size()-1].add_history("Was placed in "+name);
}
void sector::list_book() 
{
	for(int i=0; i<books.size(); i++) 
	{
		cout << books[i].Name() << endl;
	}
}
int sector::find_book(string name) 
{
	for(int i=0; i<books.size(); i++)
	{
		if(books[i].Name()==name)
			return i;
	}
	return -1;
}
book* sector::get_book(int i) 
{
	return &(books[i]);
}
void sector::digit_book(int i) 
{
	books[i].digit();
}
void sector::download_book(int i) 
{
	books[i].download();
}
void sector::delete_book(int i) 
{
	books.erase(books.begin() + i);
}
int sector::size() 
{
	return books.size();
}
void sector::history_book(int i) 
{
	books[i].History();
}
void sector::save(ofstream& file) 
{
	file << name << endl;
	file << books.size() << endl;
	for(int i=0; i<books.size(); i++) 
	{
		books[i].save(file);
	}
}